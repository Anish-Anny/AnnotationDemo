package Annotation;

import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.*;
public class annotation{
	
	ChromeDriver driver = null;
	@Given("^I am on Facebook login page$")
	
	public void goToFacebook() {
		
	}
	
	
		
}

